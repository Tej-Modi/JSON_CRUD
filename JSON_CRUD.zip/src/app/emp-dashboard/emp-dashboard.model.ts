export class EmployeeModel {
    id: number = 0;
    email: string = '';
    password: string = '';
    confirmPassword: string = ''
    firstName: string = '';
    lastName: string = '';
    mobile: string = '';
}