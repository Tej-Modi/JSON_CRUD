import { UserService } from './../login/user.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from './api/api.service';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';


@Component({
  selector: 'app-emp-dashboard',
  templateUrl: './emp-dashboard.component.html',
  styleUrls: ['./emp-dashboard.component.css']
})
export class EmpDashboardComponent implements OnInit {
  
  formValue !: FormGroup;
  employeeData !: any;
  displayedColumns: string[] = ['first_name', 'last_name', 'email', 'phone_number'];
  dataSource = new MatTableDataSource([]);
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private _toast: ToastrService, private api: ApiService, private http: HttpClient, private router: Router, private UserService: UserService,) { }


  first: any;
  last: any;

  ngOnInit(): void {
    this.first = localStorage.getItem('firstname');
    this.last = localStorage.getItem('lastname');
    
    
    this.UserService.getAllProducts()
    .subscribe((res:any) => {
      this.employeeData = res.data;
      this.dataSource.data = this.employeeData;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      console.log(res.data);
    },
    (error) => console.log(error)) 

  }
  

  logout() {
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
  }

  
}
export interface UserDetails {
  first_name: string;
  last_name: number;
  email: number;
  phone_number: string;
}