import { ChangePasswordComponent } from './change-password/change-password.component';
import { AuthguardGuard } from './shared/authguard.guard';
import { EmpDashboardComponent } from './emp-dashboard/emp-dashboard.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from '@angular/router';
const routes: Routes = [{
  path: '', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'dashboard', component: EmpDashboardComponent, canActivate: [AuthguardGuard]},
  {path: 'changePassword', component: ChangePasswordComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  constructor(private router: Router){}
  navigator(){
    this.router.navigate['login'],
    this.router.navigate['dashboard'],
    this.router.navigate['changePassword']
  }

};


