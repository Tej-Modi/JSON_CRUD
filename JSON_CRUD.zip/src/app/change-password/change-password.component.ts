import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  isSubmitted = false;
  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
  }

    // Performing Validation
  registerForm = new FormGroup({
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(15)
    ]),
    oldPassword: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(15)
    ]),
    newPassword: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(15)
    ])
  });

  get password() {
    return this.registerForm.get('password');
  }
  
  get oldPassword() {
    return this.registerForm.get('oldPassword');
  }

  get newPassword() {
    return this.registerForm.get('newPassword');
  }

    // On Clicking the submit button
  onSubmit() {
    this.isSubmitted = true;
    if(this.registerForm.valid){
    var formData: any = new FormData();
    formData.append('password', this.registerForm.get('password').value);
    formData.append('password_confirmation', this.registerForm.get('oldPassword').value);
    formData.append('newpassword', this.registerForm.get('newPassword').value);

    this.http
      .post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/change-password", formData)
      .subscribe({
        next: (response) => console.log(response),
        error: (error) => console.log(error),
        
      })
      this.router.navigate(['/login']);
      
    } 
  }
}


