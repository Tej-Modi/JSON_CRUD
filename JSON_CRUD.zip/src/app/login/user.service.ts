import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router) { }

  login(data: any) {
    return this.http.post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/login", data)
  }

  getAllProducts(): Observable<any[]> {
    let token = localStorage.getItem('token')
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<any>("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/userList", );
  }

  changePassword(data: any) {
    let to = localStorage.getItem('token')
    const headers = new HttpHeaders().set('Authorization', `Bearer ${to}`);
    return this.http.post('https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/change-password', data, );
  }
  IsLoggedIn() {
    return localStorage.getItem('token')
  }
}
