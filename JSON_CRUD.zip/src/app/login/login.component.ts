import { UserService } from './user.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isSubmitted = false;
  constructor(private router: Router, private http: HttpClient, private UserService: UserService, private ToastrService: ToastrService) { }

  ngOnInit(): void {
  }

  registerForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(15)
    ])
});

  get email(){
    return this.registerForm.get('email');
  
  }

  get password(){
    return this.registerForm.get('password');
  }

      // On clicking the Submit button
  onSubmit() {
    this.isSubmitted = true;
    let data = this.registerForm.value
    console.log(data);
    this.UserService.login(data).subscribe((result: any) => {
      console.log(result.data)
      localStorage.setItem("token", result.data.access_token);
      localStorage.setItem('firstname', result.data.data.first_name);
      localStorage.setItem('lastname', result.data.data.last_name)
      this.ToastrService.success("Logged in successfully");
      this.router.navigate(['/dashboard']);
      return !!localStorage.getItem('token');
    },error => {
      this.ToastrService.error(error);
      this.router.navigate(['/login'])
    })
  }     
}




