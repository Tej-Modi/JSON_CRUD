import { UserService } from './../login/user.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  url: string = environment.apiUrl;
  isSubmitted = false;
  registerForm: FormGroup;
  constructor(private router: Router, private http: HttpClient, private UserService: UserService, private toastr: ToastrService) { }

  ngOnInit(): void {
 

                // Performing Validation
    this.registerForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
        password: new FormControl('', [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(15)
        ]),
        confirmPassword: new FormControl('', [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(15)
        ]),
        firstName: new FormControl('', [Validators.required]),
        lastName: new FormControl('', [Validators.required]),
        mobile: new FormControl('',[
          Validators.required,
          Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
        ]),
        subType: new FormControl('', [Validators.required]),
  });
}

get email() {
  return this.registerForm.get('email');
}

get password() {
  return this.registerForm.get('password');
}

get confirmPassword() {
  return this.registerForm.get('confirmPassword');
}

  get firstName() {
    return this.registerForm.get('firstName');
  }

  get lastName() {
    return this.registerForm.get('lastName');
  } 

  get mobile() {
    return this.registerForm.get('mobile');
  }

  get subType() {
    return this.registerForm.get('subType');
  }

  

      // On clicking submit button
  onSubmit() {
    this.isSubmitted = true;
    if(this.registerForm.valid){
    var formData: any = new FormData();
    formData.append('email', this.registerForm.get('email').value);
    formData.append('password', this.registerForm.get('password').value);
    formData.append('password_confirmation', this.registerForm.get('confirmPassword').value);
    formData.append('first_name', this.registerForm.get('firstName').value);
    formData.append('last_name', this.registerForm.get('lastName').value);
    formData.append('phone_number', this.registerForm.get('mobile').value);
    formData.append('subscription_type', this.registerForm.get('subType').value);

    this.http
        .post(this.url + "/v1/register", formData)
        .subscribe({
          next: (response:any) => {
            if(response.status_code === 200){
              this.toastr.success("Registered Successfully");
              this.router.navigate(['/login']);
            } else {
            this.toastr.error(response.error)
            }
          },
          error: (error) => this.toastr.error(error),
          
        })
    }
  }
}

